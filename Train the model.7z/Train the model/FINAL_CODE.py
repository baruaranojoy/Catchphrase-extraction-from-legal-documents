import ast
import glob, os
import numpy as np
import random
import tensorflow as tf
import random

def choto(features):
    first = []
    second = []
    third = []
    sto = []
    for k in range(len(features)):
        data = features[k]
        if data[1] == [1, 0]:
            first.append(features[k])
        else:
            second.append(features[k])

    print ("1:", len(first))
    print ("2:", len(second))
    
    if len(first) > 2 * len(second):
        for m in range(int(2 * len(second))):
            loc = random.randint(0,len(first) - 1)
            if loc not in sto:
                sto.append(loc)
                third.append(first[loc])

        fourth = []
        for k in range(len(first)):
            fourth.append(first[k])
        for n in range(len(second)):
            fourth.append(second[n])

        print ("3:", len(third))
        
        return fourth
    else:
        return features
    

def choose(features):
    data = []
    flag = 0
    for k in range(len(features)):
        flag = 0
        if features[k] in data:
            flag = 1
        else:
            data.append(features[k])
    return data

def create_feature_sets_and_labels(test_size = 0.1):

    os.chdir("C:/Users/User/Desktop/FIRE/Train the model/Combine_Features")
    all_file_name = (glob.glob("*.txt"))

    features = []
    
    #for k in range(5):
    for k in range(len(all_file_name)):
        fopen = open(all_file_name[k], "r")

        while 1:
            data = fopen.readline()
            if not data:
                break
            data = ast.literal_eval(data)
            features.append(data)

    features = choose(features)
    features = choto(features)
    print (len(features))
    random.shuffle(features)
    features = np.array(features)

    # split a portion of the features into tests
    testing_size = int(test_size*len(features))

    # create train and test lists
    train_x = list(features[:,0][:-testing_size])
    train_y = list(features[:,1][:-testing_size])
    test_x = list(features[:,0][-testing_size:])
    test_y = list(features[:,1][-testing_size:])

    return train_x, train_y, test_x, test_y







train_x, train_y, test_x, test_y = create_feature_sets_and_labels()



# hidden layers and their nodes
n_nodes_hl1 = 28
n_nodes_hl2 = 28

# classes in our output
n_classes = 2
# iterations and batch-size to build out model
hm_epochs = 200
batch_size = 20
    
x = tf.placeholder('float')
y = tf.placeholder('float')

# random weights and bias for our layers
hidden_1_layer = {'f_fum':n_nodes_hl1,
                  'weight':tf.Variable(tf.random_normal([len(train_x[0]), n_nodes_hl1])),
                  'bias':tf.Variable(tf.random_normal([n_nodes_hl1]))}

hidden_2_layer = {'f_fum':n_nodes_hl2,
                  'weight':tf.Variable(tf.random_normal([n_nodes_hl1, n_nodes_hl2])),
                  'bias':tf.Variable(tf.random_normal([n_nodes_hl2]))}

output_layer = {'f_fum':None,
                'weight':tf.Variable(tf.random_normal([n_nodes_hl2, n_classes])),
                'bias':tf.Variable(tf.random_normal([n_classes])),}

















# our predictive model's definition
def neural_network_model(data):

    # hidden layer 1: (data * W) + b
    l1 = tf.add(tf.matmul(data,hidden_1_layer['weight']), hidden_1_layer['bias'])
    l1 = tf.sigmoid(l1)

    # hidden layer 2: (hidden_layer_1 * W) + b
    l2 = tf.add(tf.matmul(l1,hidden_2_layer['weight']), hidden_2_layer['bias'])
    l2 = tf.sigmoid(l2)

    # output: (hidden_layer_2 * W) + b
    output = tf.matmul(l2,output_layer['weight']) + output_layer['bias']

    return output



















# training our model
def train_neural_network(x):
    # use the model definition
    prediction = neural_network_model(x)

    # formula for cost (error)
    cost = tf.reduce_mean( tf.nn.softmax_cross_entropy_with_logits(logits=prediction, labels=y) )
    # optimize for cost using GradientDescent
    optimizer = tf.train.GradientDescentOptimizer(1).minimize(cost)

    # Tensorflow session
    with tf.Session() as sess:
        # initialize our variables
        sess.run(tf.global_variables_initializer())

        # loop through specified number of iterations
        for epoch in range(hm_epochs):
            epoch_loss = 0
            i=0
            # handle batch sized chunks of training data
            while i < len(train_x):
                start = i
                end = i+batch_size
                batch_x = np.array(train_x[start:end])
                batch_y = np.array(train_y[start:end])

                _, c = sess.run([optimizer, cost], feed_dict={x: batch_x, y: batch_y})
                epoch_loss += c
                i+=batch_size
                last_cost = c

            # print cost updates along the way
            if (epoch% (hm_epochs/5)) == 0:
                print('Epoch', epoch, 'completed out of',hm_epochs,'cost:', last_cost)
        
        # print accuracy of our model
        correct = tf.equal(tf.argmax(prediction, 1), tf.argmax(y, 1))
        accuracy = tf.reduce_mean(tf.cast(correct, 'float'))
        print('Accuracy:',accuracy.eval({x:test_x, y:test_y}))


        ori_acc = 0.0
        ori_acc_zero = 0.0
        ori_acc_one = 0.0
        ori_acc_two = 0.0
        ori_acc_three = 0.0
        # print predictions using our model
        for i,t in enumerate(test_x):
            #print ('prediction for:', test_x[i])
            output = prediction.eval(feed_dict = {x: [test_x[i]]})
            # normalize the prediction values
            #print (output)
            #print (test_y[i])
            #print(tf.sigmoid(output[0][0]).eval(), tf.sigmoid(output[0][1]).eval(), tf.sigmoid(output[0][2]).eval(), tf.sigmoid(output[0][3]).eval())

            if np.argmax(output) == np.argmax(test_y[i]):
                ori_acc += 1.0
            if np.argmax(output) == np.argmax(test_y[i]) and np.argmax(test_y[i]) == 0:
                ori_acc_zero += 1.0
            if np.argmax(output) == np.argmax(test_y[i]) and np.argmax(test_y[i]) == 1:
                ori_acc_one += 1.0
##            if np.argmax(output) == np.argmax(test_y[i]) and np.argmax(test_y[i]) == 2:
##                ori_acc_two += 1.0
##            if np.argmax(output) == np.argmax(test_y[i]) and np.argmax(test_y[i]) == 3:
##                ori_acc_three += 1.0

        print ((ori_acc / len(test_x)) * 100.0)

        po = 0.0
        for k in range(len(test_y)):
            da = test_y[k]
            if da[0] == 1:
                po += 1.0
        if po != 0.0:
            print ((ori_acc_zero / po) * 100.0)
        else:
            print (0.0)

            
        po = 0.0
        for k in range(len(test_y)):
            da = test_y[k]
            if da[1] == 1:
                po += 1.0
        if po != 0.0:
            print ((ori_acc_one / po) * 100.0)
        else:
            print (0.0)


        #print ("\n press y to proceed")
        #lu = input()

        #if lu == 'y' or lu == 'Y':
        if True:

            os.chdir("C:/Users/User/Desktop/FIRE/Fire_2/Combine_Features")
            all_file_name_pp = (glob.glob("*.txt"))

            #for b in range(len(all_file_name_pp)):
            for b in range(10):

                salo = 222
    
                print ("Prediction for file number : ", b)
                
                os.chdir("C:/Users/User/Desktop/FIRE/Fire_2/Combine_Features")
                fopen = open(all_file_name_pp[b + salo], "r")

                os.chdir("C:/Users/User/Desktop/FIRE/Fire_2/Combine_Features_Result/4")
                fopen_2 = open(all_file_name_pp[b + salo], "w")

                counter = 0
                while 1:
                    if counter % 100 == 0:
                        print (counter)
                    counter += 1
                
                    data = fopen.readline()
                    if not data:
                        break
                    data = ast.literal_eval(data)
                    #print (data)
                    output = prediction.eval(feed_dict = {x: [data]})
                    result = (tf.sigmoid(output[0][0]).eval(), tf.sigmoid(output[0][1]).eval())
                    result = list(result)

                    #fopen_2.write(str(result) + "\n")
                
                    high = np.argmax(result)
                    polo = []
                    for q in range(len(result)):
                        if q == high:
                            polo.append(1)
                        else:
                            polo.append(0)

                    #fopen_2.write(str(polo) + "\n")
                    fopen_2.write(str(result) + "\n")
                    
                fopen_2.close()
                fopen.close()

                del output
                del result
                del high
                del polo
                
                
        else:
            print ("Go try again !!")           

            
            
train_neural_network(x)

    
    
